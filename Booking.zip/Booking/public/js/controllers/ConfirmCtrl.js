
angular.module('ConfirmCtrl', []).controller('ConfirmController', function($scope,$http, $rootScope, $location) {

$scope.confirm="Confirm your Tickets";
$scope.totalSeats=$rootScope.totalSeats; 
$scope.totalPrice=$rootScope.totalPrice; 

$scope.shows = true;
$scope.details = false;  

    $scope.changePrice = function () {
		 
		var total=$scope.quantity*$rootScope.totalPrice;
        $scope.totalPrice=total;
    };
	
	$scope.bookTicket = function () {
		 $scope.shows = false;
	     $scope.details = true;
		 var bookingid=Math.floor((Math.random() * 1000000) + 1);
        $scope.msg="Your Ticket has been booked Successfully. Your Booking Id is: "+bookingid;
    };

});